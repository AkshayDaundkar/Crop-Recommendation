import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-enquiry',
  templateUrl: './resource-enquiry.component.html',
  styleUrls: ['./resource-enquiry.component.css']
})
export class ResourceEnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
