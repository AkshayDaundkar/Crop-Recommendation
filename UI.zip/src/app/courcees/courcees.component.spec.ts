import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourceesComponent } from './courcees.component';

describe('CourceesComponent', () => {
  let component: CourceesComponent;
  let fixture: ComponentFixture<CourceesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourceesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourceesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
