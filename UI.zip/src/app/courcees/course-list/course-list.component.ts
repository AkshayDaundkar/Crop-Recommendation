import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Resource } from 'src/app/shared/resource.model';
import { ResourceService } from 'src/app/shared/resource.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {
  constructor(public service : ResourceService,private toastr:ToastrService) { }

  ngOnInit(): void {
    this.service.refreshList();
  }

  populateForm(emp:Resource){
    this.service.formData=Object.assign({},emp);
  }
  
  onDelete(id: number) {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteResource(id).subscribe(res => {
        this.service.refreshList();
        this.toastr.warning('Deleted successfully', 'EMP.Register');
      });
    }
  }


}
