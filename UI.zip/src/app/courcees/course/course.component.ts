import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ResourceService } from 'src/app/shared/resource.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  constructor(public service :ResourceService,private toastr:ToastrService) { 
    
  }

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?:NgForm){
    if(form!=null)
      form.resetForm();
    this.service.formData={
      ResourceId :0,
      ResourceName :'',
      ResourceDesc :'',
      ResourcePrice :0,     
      Type :'' ,
      Visibility :false
    }
  }

  onSubmit(form:NgForm)
  {
    if(form.value.ResourceId==null)
      this.insertRecord(form);
    else
      this.updateRecord(form);
      this.service.refreshList(); 
  } 

  insertRecord(form:NgForm){
    this.service.postResource(form.value).subscribe(res=>{
      this.toastr.success('Record of Resource Inserted Sucessfully','R Register');
      this.resetForm(form);
    },
    (err)=>{
      this.toastr.success('Record of Resource Inserted Sucessfully','R Register');
      this.resetForm(form);
    }
    )
  }

  updateRecord(form:NgForm){
    this.service.putResource(form.value).subscribe(res=>{
      this.toastr.warning('Record of Resource Updated Sucessfully','R Register');
      this.resetForm(form);
    },
    (err)=>{
      this.toastr.warning('Record of Resource Updated Sucessfully','R Register');
      this.resetForm(form);
    }
    )
  }
}

