import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courcees',
  templateUrl: './courcees.component.html',
  styleUrls: ['./courcees.component.css']
})
export class CourceesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
