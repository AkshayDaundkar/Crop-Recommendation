import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ResourceesComponent } from './resourcees/resourcees.component';
import { ResourceComponent } from './resourcees/resource/resource.component';
import { ResourceListComponent } from './resourcees/resource-list/resource-list.component';
import { ResourceService } from './shared/resource.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { ResourceEnquiryComponent } from './resourcees/resource-enquiry/resource-enquiry.component';
import { CourceesComponent } from './courcees/courcees.component';
import { CourseListComponent } from './courcees/course-list/course-list.component';
import { CourseComponent } from './courcees/course/course.component';
@NgModule({
  declarations: [
    AppComponent,
    ResourceesComponent,
    ResourceComponent,
    ResourceListComponent,
    ResourceEnquiryComponent,
    CourceesComponent,
    CourseListComponent,
    CourseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [ResourceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
