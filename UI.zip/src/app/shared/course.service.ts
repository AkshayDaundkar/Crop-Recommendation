import { Injectable } from '@angular/core';
import { Resource } from './resource.model';
import {HttpClient} from "@angular/common/http"
import { Course } from './course.model';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  formData: Course = new Course;
  list: Course[] = [];
  readonly rootURL="https://localhost:44367/api/Resource";

  constructor(private http:HttpClient) { }

  postResource(formData:Course)
  {
    return this.http.post(this.rootURL+'/InsertResource',formData);
  }

  refreshList(){
    this.http.get(this.rootURL+'/GetAllResource')
    .toPromise().then(res=>this.list=res as Resource[]);
  }


  putResource(formData:Resource)
  {
    return this.http.put(this.rootURL+'/UpdateResource'+formData.ResourceId,formData);
  }

  deleteResource(id : number){
    return this.http.delete(this.rootURL+'/DeleteResource/'+id);
   }
}

