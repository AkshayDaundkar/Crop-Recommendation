import { Injectable } from '@angular/core';
import { Resource } from './resource.model';
import {HttpClient} from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class ResourceService {

  formData: Resource = new Resource;
  list: Resource[] = [];
  readonly rootURL="https://localhost:44367/api/Resource";

  constructor(private http:HttpClient) { }

  postResource(formData:Resource)
  {
    return this.http.post(this.rootURL+'/InsertResource',formData);
  }

  refreshList(){
    this.http.get(this.rootURL+'/GetAllResource')
    .toPromise().then(res=>this.list=res as Resource[]);
  }


  putResource(formData:Resource)
  {
    return this.http.put(this.rootURL+'/UpdateResource'+formData.ResourceId,formData);
  }

  deleteResource(id : number){
    return this.http.delete(this.rootURL+'/DeleteResource/'+id);
   }
}

