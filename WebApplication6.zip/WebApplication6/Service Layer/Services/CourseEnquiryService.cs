﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Repository_Layer;
using Repository_Layer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class CourseEnquiryService : ICourseEnquiry
    {
        private IRepository<CourseEnquiry> _repository;
        private ApplicationDbContext context;
        private DbSet<CourseEnquiry> courseDB;
        public CourseEnquiryService(IRepository<CourseEnquiry> repository,ApplicationDbContext context)
        {
            _repository = repository;
            this.context = context;
            courseDB = context.Set<CourseEnquiry>();
        }
        public void DeleteCourseEnquiry(int Id)
        {
            CourseEnquiry course = GetCourseEnquiry(Id);
            _repository.Remove(course);
            _repository.SaveChanges();
        }

        public IEnumerable<CourseEnquiry> GetAllCoursesEnquiry()
        {
            return _repository.GetAll();
        }

        public CourseEnquiry GetCourseEnquiry(int id)
        {
            return _repository.Get(id);
        }

        public void InsertCourseEnquiry(CourseEnquiry course)
        {
            _repository.Insert(course);
        }
       
        public void UpdateCourseEnquiry(CourseEnquiry course)
        {
            _repository.Update(course);
        }

       public IEnumerable<CourseEnquiry> getStatusBasedEnquiries(string status)
        {
            
            return courseDB.Where(enquiry => enquiry.EnquiryStatus.CompareTo(status) == 0).AsEnumerable();

        }
        /*public void CourseEnquirySummary()
        {
            CourseEnquirySummary summary = new CourseEnquirySummary();
            summary.enquired = getStatusBasedEnquiries("Enquired").Count();
            summary.admitted = getStatusBasedEnquiries("Admitted").Count();
            summary.rejected = getStatusBasedEnquiries("Rejected").Count();
            summary.selected = getStatusBasedEnquiries("Selected").Count();

            var max1 = summary.enquired>summary.admitted ? summary.enquired : summary.admitted;
            var max2 = summary.rejected > summary.selected ? summary.rejected : summary.selected;

            var max = max1 > max2 ? max1 : max2;

            if (max == summary.enquired)
            {
                return
            }
            else if (max == summary.admitted) 
            {
                return
            }
            else if (max == summary.rejected)
            {
                return
            }
            else
            {

            }
        }*/
    }
    /*public class CourseEnquirySummary
    {
        public String mostEnquiredCourse { get; set; }
        public String leastEnquiredCourse { get; set; }
        public int enquired { get; set; } = 0;
        public int admitted { get; set; } = 0;
        public int rejected { get; set; } = 0;
        public int selected { get; set; } = 0;
    }*/
}
