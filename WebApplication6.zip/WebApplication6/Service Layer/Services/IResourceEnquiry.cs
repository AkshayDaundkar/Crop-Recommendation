﻿using Domain_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public interface IResourceEnquiry
    {
        IEnumerable<ResourceEnquiry> GetAllResourcesEnquiry();
        ResourceEnquiry GetResourceEnquiry(int id);

        void InsertResourceEnquiry(ResourceEnquiry resource);
        void UpdateResourceEnquiry(ResourceEnquiry resource);
        void DeleteResourceEnquiry(int Id);
        public IEnumerable<ResourceEnquiry> getStatusBasedEnquiries(string status);

    }
}
