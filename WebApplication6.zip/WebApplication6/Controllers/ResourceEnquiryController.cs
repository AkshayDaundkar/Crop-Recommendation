﻿using Domain_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service_Layer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResourceEnquiryController : ControllerBase
    {
        private readonly IResourceEnquiry _courseService;

        public ResourceEnquiryController(IResourceEnquiry courseService)
        {
            _courseService = courseService;
        }

        [HttpGet(nameof(GetAllEnquiries))]
        public IActionResult GetAllEnquiries()
        {
            var res = _courseService.GetAllResourcesEnquiry();
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpGet(nameof(GetEnquiry))]
        public IActionResult GetEnquiry(int id)
        {
            var res = _courseService.GetResourceEnquiry(id);
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpPost(nameof(InsertEnquiry))]
        public IActionResult InsertEnquiry(ResourceEnquiry course)
        {
            _courseService.InsertResourceEnquiry(course);
            return Ok("Data Saved SuccessFully");
        }


        [HttpPut(nameof(UpdateEnquiry))]
        public IActionResult UpdateEnquiry(ResourceEnquiry course)
        {
            _courseService.UpdateResourceEnquiry(course);
            return Ok("Data Updated Successfully");
        }

        [HttpDelete(nameof(DeleteEnquiry))]
        public IActionResult DeleteEnquiry(int id)
        {
            _courseService.DeleteResourceEnquiry(id);
            return Ok("Data Deleted Successfully");
        }

    }
}

