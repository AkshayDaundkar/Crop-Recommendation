﻿using Domain_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service_Layer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseEnquiryController : ControllerBase
    {
        private readonly ICourseEnquiry _courseService;

        public CourseEnquiryController(ICourseEnquiry courseService)
        {
            _courseService = courseService;
        }

        [HttpGet]
        public IActionResult GetAllEnquiries()
        {
            var res = _courseService.GetAllCoursesEnquiry();
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpGet("{id}")]
        public IActionResult GetEnquiry(int id)
        {
            var res = _courseService.GetCourseEnquiry(id);
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpPost]
        public IActionResult InsertEnquiry(CourseEnquiry course)
        {
            _courseService.InsertCourseEnquiry(course);
            return Ok("Data Saved SuccessFully");
        }


        [HttpPut]
        public IActionResult UpdateEnquiry(CourseEnquiry course)
        {
            _courseService.UpdateCourseEnquiry(course);
            return Ok("Data Updated Successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEnquiry(int id)
        {
            _courseService.DeleteCourseEnquiry(id);
            return Ok("Data Deleted Successfully");
        }
        [HttpGet("status/{Status}")]
        public IActionResult GetStatusBasedEnquiries(String Status)
        {
            return Ok(_courseService.getStatusBasedEnquiries(Status));
        }

    }
}
