﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.Models
{
    public partial class Resource:BaseEntity
    {
        public Resource()
        {
            ResourceEnquiries = new HashSet<ResourceEnquiry>();

        }
        public string ResourceName { get; set; }
        public string ResourceDesc { get; set; }
        public decimal ResourcePrice { get; set; }        
        public string Type { get; set; }
        public bool Visibility { get; set; }

        public virtual ICollection<ResourceEnquiry> ResourceEnquiries { get; set; }

    }
}
