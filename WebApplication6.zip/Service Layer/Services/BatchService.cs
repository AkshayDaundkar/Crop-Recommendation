﻿using Domain_Layer.Models;
using Repository_Layer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class BatchService : IBatchService
    {
        private IRepository<Batch> _repository;
        public BatchService(IRepository<Batch> repository)
        {
            _repository = repository;
        }

        public void DeleteBatch(int Id)
        {
            Batch batch = GetBatch(Id);
            _repository.Remove(batch);
            _repository.SaveChanges();
        }

        public IEnumerable<Batch> GetAllBatches()
        {
           return _repository.GetAll();
        }

        public Batch GetBatch(int id)
        {
            return _repository.Get(id);
        }

        public void InsertBatch(Batch batch)
        {
            _repository.Insert(batch);
        }

        public void UpdateBatch(Batch batch)
        {
            _repository.Update(batch);
        }
    }
}
