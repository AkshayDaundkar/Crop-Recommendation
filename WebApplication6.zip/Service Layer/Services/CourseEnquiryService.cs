﻿using Domain_Layer.Models;
using Repository_Layer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class CourseEnquiryService : ICourseEnquiry
    {
        private IRepository<CourseEnquiry> _repository;
        public CourseEnquiryService(IRepository<CourseEnquiry> repository)
        {
            _repository = repository;
        }
        public void DeleteCourseEnquiry(int Id)
        {
            CourseEnquiry course = GetCourseEnquiry(Id);
            _repository.Remove(course);
            _repository.SaveChanges();
        }

        public IEnumerable<CourseEnquiry> GetAllCoursesEnquiry()
        {
            return _repository.GetAll();
        }

        public CourseEnquiry GetCourseEnquiry(int id)
        {
            return _repository.Get(id);
        }

        public void InsertCourseEnquiry(CourseEnquiry course)
        {
            _repository.Insert(course);
        }
       
        public void UpdateCourseEnquiry(CourseEnquiry course)
        {
            _repository.Update(course);
        }

       
    }
}
